import React from 'react';
function Home() { return <h1>MAINNET EDGE - Landing Page</h1>; }
export default Home;