# MAINNET EDGE

This is the MAINNET EDGE React project.

## Deployment (Vercel)
1. Go to [Vercel](https://vercel.com/)
2. Create a new project and import this folder.
3. Deploy and your app will be live.

## Pages
- `/` Landing Page
- `/services`
- `/clients`
- `/blog`
- `/contact`
- `/email-signature-preview`

## Configs
- EmailJS: Already integrated with your Service ID and Public Key.
- GA4: Tracking ID G-PGEXWFC7CG embedded.
