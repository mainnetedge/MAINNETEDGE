import React from 'react';
import blogs from '../data/blogs.json';
function Blog() { return <div><h1>Blog</h1>{blogs.map((b,i)=><div key={i}><h2>{b.title}</h2><p>{b.excerpt}</p></div>)}</div>; }
export default Blog;