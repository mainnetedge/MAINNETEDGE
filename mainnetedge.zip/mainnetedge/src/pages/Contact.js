import React from 'react';
function Contact() { return <h1>Contact Form (EmailJS integrated)</h1>; }
export default Contact;