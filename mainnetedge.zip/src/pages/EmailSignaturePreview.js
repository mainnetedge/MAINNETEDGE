import React from 'react';
function EmailSignaturePreview() { return <h1>Email Signature Preview</h1>; }
export default EmailSignaturePreview;