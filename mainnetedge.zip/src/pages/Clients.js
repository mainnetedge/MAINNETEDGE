import React from 'react';
import clients from '../data/clients.json';
function Clients() { return <div><h1>Client Stories</h1>{clients.map((c,i)=><div key={i}><h2>{c.name}</h2><p>{c.story}</p></div>)}</div>; }
export default Clients;