import React from 'react';
import services from '../data/services.json';
function Services() { return <div><h1>Services</h1>{services.map((s,i)=><div key={i}><h2>{s.title}</h2><p>{s.description}</p></div>)}</div>; }
export default Services;